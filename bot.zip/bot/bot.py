#!/usr/bin/env python3
import logging
import os
import json
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
)
from database import Database

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

TOKEN = os.environ["BOT_TOKEN"]
OWNER_ID = int(os.environ["OWNER_ID"])
CHANNEL_ID = os.environ["CHANNEL_ID"]
TZ = ZoneInfo(os.getenv("TIMEZONE", "Europe/Moscow"))

db = Database("/data/bot.db")

# {media_group_id: {"user_id": int, "chat_id": int, "ids": list[int]}}
media_groups: dict = {}


# ── Keyboards ──────────────────────────────────────────────────────────────────

def kb_post_actions() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👁 Предпросмотр", callback_data="post:preview"),
            InlineKeyboardButton("📤 Опубликовать", callback_data="post:publish"),
        ],
        [
            InlineKeyboardButton("📅 Отложить",   callback_data="post:schedule"),
            InlineKeyboardButton("💾 Черновик",    callback_data="post:draft"),
        ],
        [InlineKeyboardButton("❌ Отмена", callback_data="post:cancel")],
    ])


def kb_after_preview() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📤 Опубликовать", callback_data="post:publish"),
            InlineKeyboardButton("📅 Отложить",     callback_data="post:schedule"),
        ],
        [
            InlineKeyboardButton("💾 Черновик", callback_data="post:draft"),
            InlineKeyboardButton("❌ Отмена",   callback_data="post:cancel"),
        ],
    ])


def kb_draft(draft_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👁 Просмотр",       callback_data=f"draft:preview:{draft_id}"),
            InlineKeyboardButton("📤 Опубликовать",   callback_data=f"draft:publish:{draft_id}"),
        ],
        [
            InlineKeyboardButton("📅 Запланировать",  callback_data=f"draft:schedule:{draft_id}"),
            InlineKeyboardButton("🗑 Удалить",         callback_data=f"draft:delete:{draft_id}"),
        ],
    ])


def kb_scheduled(post_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📤 Опубликовать сейчас", callback_data=f"sched:now:{post_id}"),
            InlineKeyboardButton("🗑 Отменить",             callback_data=f"sched:cancel:{post_id}"),
        ],
    ])


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_pending(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> dict | None:
    p = context.user_data.get("pending")
    if p:
        return p
    return context.application.bot_data.get("pending_by_user", {}).get(user_id)


def clear_pending(context: ContextTypes.DEFAULT_TYPE, user_id: int):
    context.user_data.pop("pending", None)
    context.application.bot_data.get("pending_by_user", {}).pop(user_id, None)


async def copy_to(bot, chat_id, from_chat_id: int, message_ids: list[int]):
    if len(message_ids) == 1:
        return await bot.copy_message(
            chat_id=chat_id,
            from_chat_id=from_chat_id,
            message_id=message_ids[0],
        )
    return await bot.copy_messages(
        chat_id=chat_id,
        from_chat_id=from_chat_id,
        message_ids=message_ids,
    )


def now_str(tz=TZ) -> str:
    return datetime.now(tz).strftime("%d.%m.%Y %H:%M")


# ── Message handler ───────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not db.is_allowed(user.id, OWNER_ID):
        await update.message.reply_text("⛔ Нет доступа.")
        return

    extra = "\n/users — управление доступом" if user.id == OWNER_ID else ""
    await update.message.reply_text(
        f"👋 Привет, <b>{user.first_name}</b>!\n\n"
        "Отправь любое сообщение — я покажу варианты публикации.\n\n"
        "<b>Команды:</b>\n"
        "/drafts — черновики\n"
        "/scheduled — отложенные посты"
        + extra,
        parse_mode="HTML",
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user_id = update.effective_user.id

    if not db.is_allowed(user_id, OWNER_ID):
        return

    # Route to schedule input if we're waiting for date/time
    if context.user_data.get("awaiting_schedule"):
        if msg.text:
            await _process_schedule_text(update, context)
        else:
            await msg.reply_text("Пожалуйста, введите дату и время текстом (ДД.ММ.ГГГГ ЧЧ:ММ).")
        return

    # Collect media group
    if msg.media_group_id:
        gid = msg.media_group_id
        if gid not in media_groups:
            media_groups[gid] = {"user_id": user_id, "chat_id": msg.chat_id, "ids": []}
            context.job_queue.run_once(_finish_media_group, 1.5, data=gid, name=f"mg_{gid}")
        media_groups[gid]["ids"].append(msg.message_id)
        return

    # Single message
    context.user_data["pending"] = {
        "from_chat_id": msg.chat_id,
        "message_ids": [msg.message_id],
    }
    await msg.reply_text("Что сделать с этим сообщением?", reply_markup=kb_post_actions())


async def _finish_media_group(context: ContextTypes.DEFAULT_TYPE):
    gid = context.job.data
    if gid not in media_groups:
        return
    data = media_groups.pop(gid)
    user_id = data["user_id"]

    if "pending_by_user" not in context.application.bot_data:
        context.application.bot_data["pending_by_user"] = {}
    context.application.bot_data["pending_by_user"][user_id] = {
        "from_chat_id": data["chat_id"],
        "message_ids": sorted(data["ids"]),
    }

    await context.bot.send_message(
        chat_id=user_id,
        text=f"✅ Альбом получен ({len(data['ids'])} файлов). Что с ним делать?",
        reply_markup=kb_post_actions(),
    )


# ── Post callbacks ────────────────────────────────────────────────────────────

async def handle_post_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    user_id = q.from_user.id
    action = q.data.split(":")[1]

    if action == "cancel":
        clear_pending(context, user_id)
        await q.edit_message_text("❌ Отменено.")
        return

    pending = get_pending(context, user_id)
    if not pending:
        await q.edit_message_text("❌ Сообщение не найдено. Отправьте его снова.")
        return

    from_chat_id = pending["from_chat_id"]
    message_ids = pending["message_ids"]

    if action == "preview":
        await q.edit_message_text("👁 Так пост будет выглядеть в канале:")
        try:
            await copy_to(context.bot, user_id, from_chat_id, message_ids)
        except Exception as e:
            await context.bot.send_message(user_id, f"❌ Ошибка предпросмотра: {e}")
            return
        await context.bot.send_message(
            user_id, "Выберите действие:", reply_markup=kb_after_preview()
        )

    elif action == "publish":
        try:
            await copy_to(context.bot, CHANNEL_ID, from_chat_id, message_ids)
            clear_pending(context, user_id)
            await q.edit_message_text("✅ Опубликовано в канале!")
        except Exception as e:
            await q.edit_message_text(f"❌ Ошибка публикации: {e}")

    elif action == "draft":
        db.save_draft(user_id, from_chat_id, json.dumps(message_ids))
        clear_pending(context, user_id)
        await q.edit_message_text("💾 Сохранено в черновики. Смотри /drafts.")

    elif action == "schedule":
        context.user_data["pending_for_schedule"] = pending
        clear_pending(context, user_id)
        context.user_data["awaiting_schedule"] = True
        await q.edit_message_text(
            f"📅 Введите дату и время публикации:\n"
            f"<code>ДД.ММ.ГГГГ ЧЧ:ММ</code>\n\n"
            f"Сейчас: <b>{now_str()}</b> (МСК)\n\n"
            f"Пример: <code>25.12.2025 15:00</code>",
            parse_mode="HTML",
        )


async def _process_schedule_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    pending = context.user_data.get("pending_for_schedule")

    if not pending:
        context.user_data.pop("awaiting_schedule", None)
        return

    try:
        dt = datetime.strptime(text, "%d.%m.%Y %H:%M").replace(tzinfo=TZ)
    except ValueError:
        await update.message.reply_text(
            "❌ Неверный формат. Введите:\n<code>ДД.ММ.ГГГГ ЧЧ:ММ</code>\n"
            "Например: <code>25.12.2025 15:00</code>",
            parse_mode="HTML",
        )
        return

    if dt <= datetime.now(TZ):
        await update.message.reply_text("❌ Это время уже прошло. Введите другое.")
        return

    from_chat_id = pending["from_chat_id"]
    message_ids = pending["message_ids"]
    user_id = update.effective_user.id

    post_id = db.save_scheduled(user_id, from_chat_id, json.dumps(message_ids), dt.isoformat())
    delay = (dt - datetime.now(TZ)).total_seconds()
    context.job_queue.run_once(
        _publish_scheduled,
        delay,
        data={"post_id": post_id, "from_chat_id": from_chat_id, "message_ids": message_ids},
        name=f"sched_{post_id}",
    )

    context.user_data.pop("awaiting_schedule", None)
    context.user_data.pop("pending_for_schedule", None)

    if pending.get("draft_id"):
        db.delete_draft(pending["draft_id"])

    await update.message.reply_text(
        f"⏰ Пост запланирован на <b>{dt.strftime('%d.%m.%Y %H:%M')}</b> (МСК).\n"
        f"Управление: /scheduled",
        parse_mode="HTML",
    )


async def _publish_scheduled(context: ContextTypes.DEFAULT_TYPE):
    data = context.job.data
    try:
        await copy_to(context.bot, CHANNEL_ID, data["from_chat_id"], data["message_ids"])
        db.mark_scheduled_published(data["post_id"])
        logger.info("Published scheduled post %s", data["post_id"])
    except Exception as e:
        db.mark_scheduled_failed(data["post_id"])
        logger.error("Failed to publish scheduled post %s: %s", data["post_id"], e)


# ── Drafts ────────────────────────────────────────────────────────────────────

async def cmd_drafts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not db.is_allowed(user_id, OWNER_ID):
        return

    drafts = db.get_drafts(user_id)
    if not drafts:
        await update.message.reply_text("📭 Черновиков нет.")
        return

    for d in drafts:
        dt_str = datetime.fromisoformat(d["created_at"]).strftime("%d.%m %H:%M")
        ids = json.loads(d["message_ids"])
        label = f"альбом ({len(ids)} файлов)" if len(ids) > 1 else "сообщение"
        await update.message.reply_text(
            f"📝 Черновик <b>#{d['id']}</b> · {label} · сохранён {dt_str}",
            parse_mode="HTML",
            reply_markup=kb_draft(d["id"]),
        )


async def handle_draft_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    user_id = q.from_user.id
    _, action, draft_id_str = q.data.split(":")
    draft_id = int(draft_id_str)

    draft = db.get_draft(draft_id)
    if not draft or draft["user_id"] != user_id:
        await q.edit_message_text("❌ Черновик не найден.")
        return

    from_chat_id = draft["from_chat_id"]
    message_ids = json.loads(draft["message_ids"])

    if action == "delete":
        db.delete_draft(draft_id)
        await q.edit_message_text("🗑 Черновик удалён.")

    elif action == "preview":
        await q.edit_message_text("👁 Предпросмотр черновика:")
        try:
            await copy_to(context.bot, user_id, from_chat_id, message_ids)
        except Exception as e:
            await context.bot.send_message(user_id, f"❌ Ошибка: {e}")

    elif action == "publish":
        try:
            await copy_to(context.bot, CHANNEL_ID, from_chat_id, message_ids)
            db.delete_draft(draft_id)
            await q.edit_message_text("✅ Черновик опубликован!")
        except Exception as e:
            await q.edit_message_text(f"❌ Ошибка: {e}")

    elif action == "schedule":
        context.user_data["pending_for_schedule"] = {
            "from_chat_id": from_chat_id,
            "message_ids": message_ids,
            "draft_id": draft_id,
        }
        context.user_data["awaiting_schedule"] = True
        await q.edit_message_text(
            f"📅 Введите дату и время публикации:\n"
            f"<code>ДД.ММ.ГГГГ ЧЧ:ММ</code>\n\n"
            f"Сейчас: <b>{now_str()}</b> (МСК)",
            parse_mode="HTML",
        )


# ── Scheduled posts ───────────────────────────────────────────────────────────

async def cmd_scheduled(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not db.is_allowed(user_id, OWNER_ID):
        return

    posts = db.get_scheduled(user_id)
    if not posts:
        await update.message.reply_text("📭 Нет отложенных постов.")
        return

    for p in posts:
        dt_str = datetime.fromisoformat(p["scheduled_at"]).astimezone(TZ).strftime("%d.%m.%Y %H:%M")
        ids = json.loads(p["message_ids"])
        label = f"альбом ({len(ids)} файлов)" if len(ids) > 1 else "сообщение"
        await update.message.reply_text(
            f"⏰ Пост <b>#{p['id']}</b> · {label} · <b>{dt_str}</b> (МСК)",
            parse_mode="HTML",
            reply_markup=kb_scheduled(p["id"]),
        )


async def handle_sched_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    _, action, post_id_str = q.data.split(":")
    post_id = int(post_id_str)

    post = db.get_scheduled_post(post_id)
    if not post:
        await q.edit_message_text("❌ Пост не найден.")
        return

    if action == "cancel":
        for job in context.job_queue.get_jobs_by_name(f"sched_{post_id}"):
            job.schedule_removal()
        db.delete_scheduled(post_id)
        await q.edit_message_text("🗑 Запланированный пост отменён.")

    elif action == "now":
        from_chat_id = post["from_chat_id"]
        message_ids = json.loads(post["message_ids"])
        try:
            await copy_to(context.bot, CHANNEL_ID, from_chat_id, message_ids)
            for job in context.job_queue.get_jobs_by_name(f"sched_{post_id}"):
                job.schedule_removal()
            db.mark_scheduled_published(post_id)
            await q.edit_message_text("✅ Опубликовано досрочно!")
        except Exception as e:
            await q.edit_message_text(f"❌ Ошибка: {e}")


# ── User management ───────────────────────────────────────────────────────────

async def cmd_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        await update.message.reply_text("⛔ Только для владельца бота.")
        return

    users = db.get_users()
    if users:
        lines = ["👥 <b>Пользователи с доступом:</b>\n"]
        for u in users:
            name = f"@{u['username']}" if u["username"] else "без username"
            lines.append(f"• {name} — <code>{u['user_id']}</code>")
        text = "\n".join(lines)
    else:
        text = "👥 Нет добавленных пользователей."

    text += (
        "\n\n<b>Добавить:</b>\n<code>/add_user &lt;user_id&gt; [username]</code>\n"
        "<b>Удалить:</b>\n<code>/remove_user &lt;user_id&gt;</code>\n\n"
        "💡 User ID можно узнать через @userinfobot"
    )
    await update.message.reply_text(text, parse_mode="HTML")


async def cmd_add_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    if not context.args:
        await update.message.reply_text(
            "Использование: <code>/add_user &lt;user_id&gt; [username]</code>",
            parse_mode="HTML",
        )
        return
    try:
        uid = int(context.args[0])
        uname = context.args[1].lstrip("@") if len(context.args) > 1 else ""
        db.add_user(uid, uname, OWNER_ID)
        label = f"@{uname}" if uname else str(uid)
        await update.message.reply_text(f"✅ Пользователь {label} добавлен.")
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Неверный формат.")


async def cmd_remove_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    if not context.args:
        await update.message.reply_text(
            "Использование: <code>/remove_user &lt;user_id&gt;</code>",
            parse_mode="HTML",
        )
        return
    try:
        uid = int(context.args[0])
        db.remove_user(uid)
        await update.message.reply_text(f"✅ Пользователь {uid} удалён.")
    except ValueError:
        await update.message.reply_text("❌ Неверный user_id.")


# ── Restore scheduled jobs on startup ─────────────────────────────────────────

async def post_init(app: Application):
    posts = db.get_all_pending_scheduled()
    now = datetime.now(TZ)
    restored = 0
    for post in posts:
        scheduled_at = datetime.fromisoformat(post["scheduled_at"]).astimezone(TZ)
        message_ids = json.loads(post["message_ids"])
        data = {
            "post_id": post["id"],
            "from_chat_id": post["from_chat_id"],
            "message_ids": message_ids,
        }
        if scheduled_at <= now:
            try:
                await copy_to(app.bot, CHANNEL_ID, post["from_chat_id"], message_ids)
                db.mark_scheduled_published(post["id"])
                logger.info("Published overdue post %s", post["id"])
            except Exception as e:
                logger.error("Failed overdue post %s: %s", post["id"], e)
        else:
            delay = (scheduled_at - now).total_seconds()
            app.job_queue.run_once(
                _publish_scheduled, delay,
                data=data, name=f"sched_{post['id']}",
            )
            restored += 1
    if restored:
        logger.info("Restored %d scheduled job(s)", restored)


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    app = (
        Application.builder()
        .token(TOKEN)
        .post_init(post_init)
        .build()
    )

    app.add_handler(CommandHandler("start",       cmd_start))
    app.add_handler(CommandHandler("drafts",      cmd_drafts))
    app.add_handler(CommandHandler("scheduled",   cmd_scheduled))
    app.add_handler(CommandHandler("users",       cmd_users))
    app.add_handler(CommandHandler("add_user",    cmd_add_user))
    app.add_handler(CommandHandler("remove_user", cmd_remove_user))

    app.add_handler(CallbackQueryHandler(handle_post_callback,  pattern=r"^post:"))
    app.add_handler(CallbackQueryHandler(handle_draft_callback, pattern=r"^draft:"))
    app.add_handler(CallbackQueryHandler(handle_sched_callback, pattern=r"^sched:"))

    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, handle_message))

    logger.info("Bot started. Channel: %s  Owner: %s", CHANNEL_ID, OWNER_ID)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
