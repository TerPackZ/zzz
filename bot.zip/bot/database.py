import sqlite3
from datetime import datetime


class Database:
    def __init__(self, path: str = "/data/bot.db"):
        self.path = path
        self._init()

    def _conn(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS allowed_users (
                    user_id   INTEGER PRIMARY KEY,
                    username  TEXT DEFAULT '',
                    added_by  INTEGER,
                    added_at  TEXT
                );
                CREATE TABLE IF NOT EXISTS drafts (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id     INTEGER NOT NULL,
                    from_chat_id INTEGER NOT NULL,
                    message_ids TEXT NOT NULL,
                    created_at  TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS scheduled_posts (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id      INTEGER NOT NULL,
                    from_chat_id INTEGER NOT NULL,
                    message_ids  TEXT NOT NULL,
                    scheduled_at TEXT NOT NULL,
                    status       TEXT NOT NULL DEFAULT 'pending',
                    created_at   TEXT NOT NULL
                );
            """)

    def is_allowed(self, user_id: int, owner_id: int) -> bool:
        if user_id == owner_id:
            return True
        with self._conn() as conn:
            return conn.execute(
                "SELECT 1 FROM allowed_users WHERE user_id = ?", (user_id,)
            ).fetchone() is not None

    def add_user(self, user_id: int, username: str, added_by: int):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO allowed_users (user_id, username, added_by, added_at) VALUES (?, ?, ?, ?)",
                (user_id, username, added_by, datetime.now().isoformat()),
            )

    def remove_user(self, user_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM allowed_users WHERE user_id = ?", (user_id,))

    def get_users(self):
        with self._conn() as conn:
            return conn.execute("SELECT * FROM allowed_users ORDER BY added_at").fetchall()

    # ── Drafts ──────────────────────────────────────────────────────────────

    def save_draft(self, user_id: int, from_chat_id: int, message_ids: str) -> int:
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT INTO drafts (user_id, from_chat_id, message_ids, created_at) VALUES (?, ?, ?, ?)",
                (user_id, from_chat_id, message_ids, datetime.now().isoformat()),
            )
            return cur.lastrowid

    def get_drafts(self, user_id: int):
        with self._conn() as conn:
            return conn.execute(
                "SELECT * FROM drafts WHERE user_id = ? ORDER BY created_at DESC", (user_id,)
            ).fetchall()

    def get_draft(self, draft_id: int):
        with self._conn() as conn:
            return conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()

    def delete_draft(self, draft_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM drafts WHERE id = ?", (draft_id,))

    # ── Scheduled posts ──────────────────────────────────────────────────────

    def save_scheduled(self, user_id: int, from_chat_id: int, message_ids: str, scheduled_at: str) -> int:
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT INTO scheduled_posts (user_id, from_chat_id, message_ids, scheduled_at, status, created_at)"
                " VALUES (?, ?, ?, ?, 'pending', ?)",
                (user_id, from_chat_id, message_ids, scheduled_at, datetime.now().isoformat()),
            )
            return cur.lastrowid

    def get_scheduled(self, user_id: int):
        with self._conn() as conn:
            return conn.execute(
                "SELECT * FROM scheduled_posts WHERE user_id = ? AND status = 'pending' ORDER BY scheduled_at",
                (user_id,),
            ).fetchall()

    def get_scheduled_post(self, post_id: int):
        with self._conn() as conn:
            return conn.execute("SELECT * FROM scheduled_posts WHERE id = ?", (post_id,)).fetchone()

    def get_all_pending_scheduled(self):
        with self._conn() as conn:
            return conn.execute(
                "SELECT * FROM scheduled_posts WHERE status = 'pending' ORDER BY scheduled_at"
            ).fetchall()

    def mark_scheduled_published(self, post_id: int):
        with self._conn() as conn:
            conn.execute("UPDATE scheduled_posts SET status = 'published' WHERE id = ?", (post_id,))

    def mark_scheduled_failed(self, post_id: int):
        with self._conn() as conn:
            conn.execute("UPDATE scheduled_posts SET status = 'failed' WHERE id = ?", (post_id,))

    def delete_scheduled(self, post_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM scheduled_posts WHERE id = ?", (post_id,))
